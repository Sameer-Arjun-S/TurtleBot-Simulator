Project 2 - Group 5

Rohit Reddy Pakhala (rpakhala)
Sameer Arjun S (ssarjun)
Vineet Kumar Singh (vsingh03)



odom_updater_package - Updated package for the package
dynamic_tf2_frame_publisher - Implemented subscriber and broadcaster
m_bot_controller - Pointer using which the goal was reached
goal_detect_subscriber - A topic to the subscriber to detect fiducial marker location
goal_detect_callback - Callback method for the same
aruco_detection_subscriber - To read the topic to find the end goal
final_destination -  a frame is broadcaster is created
For achieving this, a frame is broadcaster is created which broadcasts the frame of final destination.frame id

Link to the simulation video: https://www.youtube.com/watch?v=Wf4jgUjjwj8 
